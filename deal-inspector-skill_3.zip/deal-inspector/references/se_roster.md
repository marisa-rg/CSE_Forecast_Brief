# Territory SE Roster

Source of truth: the "CSE Alignments FY27" Sigma workbook (workbookId `21184261-ac28-4d42-ac63-06d37fc6a129`), element "CAE/CSE Mapping Table" (`RxTLpHr-EM`). Re-pull from there if this list looks stale — reps get added, promoted, or leave.

Marisa's org structure (as of Aug 2026): three RVPs report to her, each with SEs underneath. DJ is no longer at Sigma; his former SEs now roll up under Adam Barlow (West) and the two East RVPs.

## Adam Barlow (West)
- Anurag Rajagopal
- Christopher Seven
- Josh Jones
- Kunal Pandit
- Medha Bhatia
- Ryan Mattel

## Arnav Sangal (East)
- Connor Miller
- Harrison Sommer
- Teresa Li
- Tyler Shaffer
- Vishnu Ram

## Tyler Johnson (East)
- Alex DoQuang
- Chad Morris
- Gabriel Jones
- Marit Taylor
- Ryan Lauderback

## Refresh query

```sql
SELECT DISTINCT "1MBL5GDMGI" AS "CSE", "3WkjvMpjqf" AS "CSE RVP"
FROM "workbook"."RxTLpHr-EM"
ORDER BY "3WkjvMpjqf", "1MBL5GDMGI"
```

Run against workbookId `21184261-ac28-4d42-ac63-06d37fc6a129` whenever the roster needs confirming, and update this file if it's changed. If Marisa says a rep has joined, left, or moved RVPs, update this file directly rather than re-querying every time.
