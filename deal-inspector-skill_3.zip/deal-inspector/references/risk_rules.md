# Risk Flag Rules

Apply these when building the Risk Flags section. Only surface a flag if it actually fires — this is a checklist for you (Claude) to evaluate, not a checklist to print in the report.

## Stalled momentum
- **Stalled in stage**: `Days in Stage` is high relative to typical cycle time for that stage (as a rule of thumb: >30 days for stages 1-3, >45 days for stages 4-5, >21 days for stage 6/Negotiation — adjust if the account's history shows a naturally longer cycle).
- **Going cold**: `Days Since Last Call` and `Days Since Last Email` both notably higher than the deal's own `Avg Days Between Calls` — i.e. it's gone quiet relative to its own historical cadence, not just quiet in absolute terms.
- **No next step**: `Opportunity Next Step` and `Last Gong Call Next Steps` are both blank, vague ("check in"), or stale (refer to a date that's passed).

## MEDPICC gaps
- **No confirmed Economic Buyer**: Medpic Payload's economic buyer field is blank, or names someone without clear buying authority per the transcripts.
- **No Champion**: Champion field blank, or the named champion hasn't appeared on a call in the last 2+ calls.
- **Vague Metric/Pain**: `Opportunity Why Anything` and the Medpic Payload's pain/metric fields are generic or missing — no quantified business impact.
- **Undefined Paper Process**: Decision Criteria / Paper Process fields blank this late in the stage (especially concerning at Stage 4+).

## Competitive/sentiment risk
- **Active competitor named**: `Opportunity Competitor` is non-null and not a throwaway/incumbent-only mention.
- **Sentiment decline**: External Speaker Transcript Sentiment Score trending downward across the last 2-3 calls, or any single recent call with a notably negative score relative to the deal's own history.
- **Low engagement**: `Num Total Participants` shrinking on more recent calls, or internal participants outnumbering external by a wide margin (signals the prospect isn't bringing people in).

## Deal-mechanics risk
- **Slipping close date**: current `Opportunity Close Date` has moved out relative to what it looked like in earlier Gong calls (`Gong Call Opp Amount Time of Call` / stage-at-call fields can help reconstruct this if needed).
- **Stage/probability mismatch**: `Opportunity Probability` implies more confidence than the MEDPICC/momentum picture supports.
- **Renewal-specific**: for existing business, expected renewal date (`Opportunity Expected Renewal Date`) close with no recent engagement.

## Writing the flags
State each flag as a plain fact plus its implication, not as jargon. E.g.: "No call in 19 days, versus this deal's usual 8-day cadence between calls — likely lost momentum, not just a scheduling gap." Not: "Engagement velocity risk detected."
